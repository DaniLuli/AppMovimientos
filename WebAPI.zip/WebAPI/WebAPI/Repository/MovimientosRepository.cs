﻿using Microsoft.EntityFrameworkCore;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Numerics;
using System.Threading.Tasks;
using WebAPI.Models;
namespace WebAPI.Repository
{
    public interface IMovimientosRepository
    {
        Task<IEnumerable<Movimientos>> GetMovimientosAsync(Movimientos objMovimientos);
        Task<int> InsertMovimientoAsync(Movimientos objMovimientos);
    }
    public class MovimientosRepository : IMovimientosRepository
    {
        private readonly APIDbContext _appDBContext;

        public MovimientosRepository(APIDbContext context)
        {
            _appDBContext = context ?? throw new ArgumentNullException(nameof(context));
        }

        public async Task<IEnumerable<Movimientos>> GetMovimientosAsync(Movimientos objMovimientos)
        {
            var parameter = new List<SqlParameter>();
            parameter.Add(new SqlParameter("@tipoMovimiento", objMovimientos.TipoMovimiento));
            parameter.Add(new SqlParameter("@nroDocumento", objMovimientos.NroDocumento));
            parameter.Add(new SqlParameter("@fechaInicio", objMovimientos.FechaTransaccion));
            parameter.Add(new SqlParameter("@fechaFin", objMovimientos.FechaTransaccion));

            var lstMovimientos = await Task.Run(() => _appDBContext.Movimientos
                            .FromSqlRaw(@"exec ListarMovimientos @tipoMovimiento, @nroDocumento, @fechaInicio, @fechaFin", parameter).ToListAsync());

            return lstMovimientos;
        }

        public async Task<int> InsertMovimientoAsync(Movimientos objMovimientos)
        {
            var parameter = new List<SqlParameter>();
            parameter.Add(new SqlParameter("@COD_CIA", objMovimientos.CodCia));
            parameter.Add(new SqlParameter("@COMPANIA_VENTA_3", objMovimientos.CompaniaVenta3));
            parameter.Add(new SqlParameter("@ALMACEN_VENTA", objMovimientos.AlmacenVenta));
            parameter.Add(new SqlParameter("@TIPO_MOVIMIENTO", objMovimientos.TipoMovimiento));
            parameter.Add(new SqlParameter("@TIPO_DOCUMENTO", objMovimientos.TipoDocumento));
            parameter.Add(new SqlParameter("@NRO_DOCUMENTO", objMovimientos.NroDocumento));
            parameter.Add(new SqlParameter("@COD_ITEM_2", objMovimientos.CodItem2));
            parameter.Add(new SqlParameter("@PROVEEDOR", objMovimientos.Proveedor));
            parameter.Add(new SqlParameter("@ALMACEN_DESTINO", objMovimientos.AlmacenDestino));
            parameter.Add(new SqlParameter("@CANTIDAD", objMovimientos.Cantidad));
            parameter.Add(new SqlParameter("@COMPANIA_DESTINO", objMovimientos.CompaniaDestino));
            parameter.Add(new SqlParameter("@COSTO_UNITARIO", objMovimientos.CostoUnitario));
            parameter.Add(new SqlParameter("@DOC_REF_1", objMovimientos.DocRef1));
            parameter.Add(new SqlParameter("@DOC_REF_2", objMovimientos.DocRef2));
            parameter.Add(new SqlParameter("@FECHA_TRANSACCION", objMovimientos.FechaTransaccion));
            parameter.Add(new SqlParameter("@MOTIVO", objMovimientos.Motivo));
            parameter.Add(new SqlParameter("@PRECIO_UNITARIO", objMovimientos.PrecioUnitario));
            parameter.Add(new SqlParameter("@TIPO_DOC_REF", objMovimientos.TipoDocRef));
            parameter.Add(new SqlParameter("@UM_ITEM_3", objMovimientos.UmItem3));
            parameter.Add(new SqlParameter("@NRO_NOTA", objMovimientos.NroNota));
            parameter.Add(new SqlParameter("@ROWVERSION", objMovimientos.RowVersion));
            parameter.Add(new SqlParameter("@USUARIO", objMovimientos.Usuario));
            parameter.Add(new SqlParameter("@MONEDA", objMovimientos.Moneda));
            parameter.Add(new SqlParameter("@COSTO_UNITARIO_ME", objMovimientos.CostoUnitarioMe));
            parameter.Add(new SqlParameter("@COS_UNIT_EST", objMovimientos.CosUnitEst));
            parameter.Add(new SqlParameter("@COS_UNIT_ME_EST", objMovimientos.CosUnitMeEst));
            parameter.Add(new SqlParameter("@HORA_TRANSACCION", objMovimientos.HoraTransaccion));
            parameter.Add(new SqlParameter("@F_ORDENCOMPRA", objMovimientos.FOrdenCompra));
            parameter.Add(new SqlParameter("@C_SEC_OC", objMovimientos.CSecOC));
            parameter.Add(new SqlParameter("@C_SEC_DET_OC", objMovimientos.CSecDetOC));
            parameter.Add(new SqlParameter("@TIPO_DOC_REF_2", objMovimientos.TipoDocRef2));
            parameter.Add(new SqlParameter("@OBSERVACION", objMovimientos.Observacion));
            parameter.Add(new SqlParameter("@FECHA_VALORIZACION", objMovimientos.FechaValorizacion));
            parameter.Add(new SqlParameter("@USUARIO_VALORIZA", objMovimientos.UsuarioValoriza));
            parameter.Add(new SqlParameter("@FACTOR", objMovimientos.Factor));
            parameter.Add(new SqlParameter("@COSTOS_ADICIONALES", objMovimientos.CostosAdicionales));
            parameter.Add(new SqlParameter("@T_CAMBIO_VALORIZA", objMovimientos.TCambioValoriza));
            parameter.Add(new SqlParameter("@PERIODO_CERRADO", objMovimientos.PeriodoCerrado));
            parameter.Add(new SqlParameter("@PLANILLA_CONSIGNA", objMovimientos.PlanillaConsigna));
            parameter.Add(new SqlParameter("@DOC_REF_3", objMovimientos.DocRef3));
            parameter.Add(new SqlParameter("@INGRESO_SALIDA", objMovimientos.IngresoSalida));
            parameter.Add(new SqlParameter("@SALDO_FINAL", objMovimientos.SaldoFinal));
            parameter.Add(new SqlParameter("@FLAG_URGENTE", objMovimientos.FlagUrgente));
            parameter.Add(new SqlParameter("@DOC_REF_4", objMovimientos.DocRef4));
            parameter.Add(new SqlParameter("@DOC_REF_5", objMovimientos.DocRef5));
            parameter.Add(new SqlParameter("@DOC_REF_6", objMovimientos.DocRef6));
            parameter.Add(new SqlParameter("@DOC_REF_7", objMovimientos.DocRef7));
            parameter.Add(new SqlParameter("@DOC_REF_8", objMovimientos.DocRef8));

            var result = await Task.Run(() => _appDBContext.Database
           .ExecuteSqlRawAsync(@"exec InsertarMovimiento ,
            @COD_CIA,
            @COMPANIA_VENTA_3,
            @ALMACEN_VENTA,
            @TIPO_MOVIMIENTO,
            @TIPO_DOCUMENTO,
            @NRO_DOCUMENTO,
            @COD_ITEM_2,
            @PROVEEDOR,
            @ALMACEN_DESTINO,
            @CANTIDAD,
            @COMPANIA_DESTINO,
            @COSTO_UNITARIO,
            @DOC_REF_1,
            @DOC_REF_2,
            @FECHA_TRANSACCION,
            @MOTIVO,
            @PRECIO_UNITARIO,
            @TIPO_DOC_REF,
            @UM_ITEM_3,
            @NRO_NOTA,
            @ROWVERSION,
            @USUARIO,
            @MONEDA,
            @COSTO_UNITARIO_ME,
            @COS_UNIT_EST,
            @COS_UNIT_ME_EST,
            @HORA_TRANSACCION,
            @F_ORDENCOMPRA,
            @C_SEC_OC,
            @C_SEC_DET_OC,
            @TIPO_DOC_REF_2,
            @OBSERVACION,
            @FECHA_VALORIZACION,
            @USUARIO_VALORIZA,
            @FACTOR,
            @COSTOS_ADICIONALES,
            @T_CAMBIO_VALORIZA,
            @PERIODO_CERRADO,
            @PLANILLA_CONSIGNA,
            @DOC_REF_3,
            @INGRESO_SALIDA,
            @SALDO_FINAL,
            @FLAG_URGENTE,
            @DOC_REF_4,
            @DOC_REF_5,
            @DOC_REF_6,
            @DOC_REF_7,
            @DOC_REF_8",
           parameter.ToArray()));

            return result;
        }

    }
}
