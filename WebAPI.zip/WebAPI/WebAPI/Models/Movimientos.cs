﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
namespace WebAPI.Models
{
    [Table("MOV_INVENTARIO")]
    public class Movimientos
    {
        public string CodCia { get; set; }
        public string CompaniaVenta3 { get; set; }
        public string AlmacenVenta { get; set; }
        public string TipoMovimiento { get; set; }
        public string TipoDocumento { get; set; }
        public string NroDocumento { get; set; }
        public string CodItem2 { get; set; }
        public string Proveedor { get; set; }
        public string AlmacenDestino { get; set; }
        public string Cantidad { get; set; }
        public string CompaniaDestino { get; set; }
        public string CostoUnitario { get; set; }
        public string DocRef1 { get; set; }
        public string DocRef2 { get; set; }
        public string FechaTransaccion { get; set; }
        public string Motivo { get; set; }
        public string PrecioUnitario { get; set; }
        public string TipoDocRef { get; set; }
        public string UmItem3 { get; set; }
        public string NroNota { get; set; }
        public string RowVersion { get; set; }
        public string Usuario { get; set; }
        public string Moneda { get; set; }
        public string CostoUnitarioMe { get; set; }
        public string CosUnitEst { get; set; }
        public string CosUnitMeEst { get; set; }
        public string HoraTransaccion { get; set; }
        public string FOrdenCompra { get; set; }
        public string CSecOC { get; set; }
        public string CSecDetOC { get; set; }
        public string TipoDocRef2 { get; set; }
        public string Observacion { get; set; }
        public string FechaValorizacion { get; set; }
        public string UsuarioValoriza { get; set; }
        public string Factor { get; set; }
        public string CostosAdicionales { get; set; }
        public string TCambioValoriza { get; set; }
        public string PeriodoCerrado { get; set; }
        public string PlanillaConsigna { get; set; }
        public string DocRef3 { get; set; }
        public string IngresoSalida { get; set; }
        public string SaldoFinal { get; set; }
        public string FlagUrgente { get; set; }
        public string DocRef4 { get; set; }
        public string DocRef5 { get; set; }
        public string DocRef6 { get; set; }
        public string DocRef7 { get; set; }
        public string DocRef8 { get; set; }
    }
}
