﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using WebAPI.Models;
using WebAPI.Repository;
namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MovimientosController : ControllerBase
    {
        private readonly IMovimientosRepository _movimientos;

        public MovimientosController(IMovimientosRepository movimientos)
        {
            _movimientos = movimientos ?? throw new ArgumentNullException(nameof(movimientos));
        }

        [HttpGet]
        [Route("GetMovimientos/{FechaInicio}/{FechaFin}/{TipoMovimiento}/{NroDocumento}")]
        public async Task<IActionResult> GetMovimientos(Movimientos movimientos)
        {
            return Ok(await _movimientos.GetMovimientosAsync(movimientos));
        }

        [HttpPost]
        [Route("InsertMovimiento")]
        public async Task<IActionResult> InsertMovimiento(Movimientos movimientos)
        {
            var result = await _movimientos.InsertMovimientoAsync(movimientos);
            if (result == 0)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Ocurrió un Error.");
            }
            return Ok("Movimiento guardado satisfactoriamente");
        }
    }
}
